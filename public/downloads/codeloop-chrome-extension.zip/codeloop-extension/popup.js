const SUPABASE_URL = 'https://khhzrsamrfkgxtbhyvda.supabase.co';
const SUPABASE_ANON_KEY =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtoaHpyc2FtcmZrZ3h0Ymh5dmRhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTAyNjQ4ODksImV4cCI6MjEwNTg0MDg4OX0.90QDd9VqEuqCFSUqFqXEtMxmiuXBbOsdclDKf2CvTww';

// ---------- DOM ----------
const $ = (id) => document.getElementById(id);
const loginView = $('loginView');
const dashboardView = $('dashboardView');
const loadingView = $('loadingView');
const logoutBtn = $('logoutBtn');

function showView(view) {
  [loginView, dashboardView, loadingView].forEach((v) => v.classList.add('hidden'));
  view.classList.remove('hidden');
}

function setStatus(msg) {
  $('statusLine').textContent = msg || '';
}

// ---------- Storage helpers ----------
function getSession() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['session'], (r) => resolve(r.session || null));
  });
}
function setSession(session) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ session }, resolve);
  });
}
function clearSession() {
  return new Promise((resolve) => {
    chrome.storage.local.remove(['session'], resolve);
  });
}

// ---------- Supabase REST calls ----------
async function signIn(email, password) {
  const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', apikey: SUPABASE_ANON_KEY },
    body: JSON.stringify({ email, password }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error_description || data.msg || 'Login failed.');
  return data; // { access_token, refresh_token, expires_at, user }
}

async function refreshAccessToken(refreshToken) {
  const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', apikey: SUPABASE_ANON_KEY },
    body: JSON.stringify({ refresh_token: refreshToken }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error('Session expired. Please log in again.');
  return data;
}

async function fetchProfile(accessToken, userId) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/profiles?id=eq.${userId}&select=id,name,username,email,role`, {
    headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${accessToken}` },
  });
  const data = await res.json();
  if (!res.ok || !Array.isArray(data) || data.length === 0) throw new Error('Could not load profile.');
  return data[0];
}

async function fetchStats(accessToken, userId) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/rpc/get_user_stats`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      apikey: SUPABASE_ANON_KEY,
      Authorization: `Bearer ${accessToken}`,
    },
    body: JSON.stringify({ target_id: userId }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || 'Could not load stats.');
  return data;
}

// Ensures we have a non-expired access token, refreshing if needed.
async function getValidSession() {
  const session = await getSession();
  if (!session) return null;
  const isExpired = !session.expires_at || Date.now() / 1000 > session.expires_at - 30;
  if (!isExpired) return session;
  try {
    const refreshed = await refreshAccessToken(session.refresh_token);
    const newSession = {
      access_token: refreshed.access_token,
      refresh_token: refreshed.refresh_token,
      expires_at: Math.floor(Date.now() / 1000) + (refreshed.expires_in || 3600),
      user: session.user,
    };
    await setSession(newSession);
    return newSession;
  } catch {
    await clearSession();
    return null;
  }
}

// ---------- Render ----------
function renderStats(profile, stats) {
  const name = profile.name || profile.email;
  $('userName').textContent = name;
  $('userEmail').textContent = profile.email;
  $('avatarInitial').textContent = (name || 'U').trim().charAt(0).toUpperCase();

  $('streakValue').textContent = stats.current_streak ?? 0;
  $('totalValue').textContent = stats.solved_total ?? 0;
  $('revisionValue').textContent = `${stats.revision_success_rate ?? 0}%`;
  $('easyValue').textContent = stats.solved_easy ?? 0;
  $('mediumValue').textContent = stats.solved_medium ?? 0;
  $('hardValue').textContent = stats.solved_hard ?? 0;
}

function renderZeroed() {
  ['streakValue', 'totalValue', 'easyValue', 'mediumValue', 'hardValue'].forEach((id) => ($(id).textContent = '0'));
  $('revisionValue').textContent = '0%';
}

// ---------- Flows ----------
async function loadDashboard() {
  showView(loadingView);
  const session = await getValidSession();
  if (!session) {
    showView(loginView);
    return;
  }
  logoutBtn.classList.remove('hidden');
  try {
    const [profile, stats] = await Promise.all([
      fetchProfile(session.access_token, session.user.id),
      fetchStats(session.access_token, session.user.id),
    ]);
    renderStats(profile, stats);
    setStatus(`Last synced ${new Date().toLocaleTimeString()}`);
    showView(dashboardView);
  } catch (err) {
    setStatus('');
    $('loginError').textContent = err.message || 'Something went wrong.';
    $('loginError').classList.remove('hidden');
    await clearSession();
    logoutBtn.classList.add('hidden');
    showView(loginView);
  }
}

async function handleLogin() {
  const email = $('emailInput').value.trim();
  const password = $('passwordInput').value;
  const errBox = $('loginError');
  errBox.classList.add('hidden');

  if (!email || !password) {
    errBox.textContent = 'Please enter your email and password.';
    errBox.classList.remove('hidden');
    return;
  }

  $('loginBtn').disabled = true;
  $('loginBtn').textContent = 'Logging in...';
  try {
    const data = await signIn(email, password);
    await setSession({
      access_token: data.access_token,
      refresh_token: data.refresh_token,
      expires_at: Math.floor(Date.now() / 1000) + (data.expires_in || 3600),
      user: { id: data.user.id, email: data.user.email },
    });
    await loadDashboard();
  } catch (err) {
    errBox.textContent = err.message || 'Login failed.';
    errBox.classList.remove('hidden');
  } finally {
    $('loginBtn').disabled = false;
    $('loginBtn').textContent = 'Log In';
  }
}

async function handleLogout() {
  await clearSession();
  logoutBtn.classList.add('hidden');
  $('emailInput').value = '';
  $('passwordInput').value = '';
  showView(loginView);
}

// Resets only what THIS popup view shows right now — does not touch your
// real data on the server. Reopen the popup (or hit Refresh) to pull your
// actual streak and solved counts again.
function handleReset() {
  renderZeroed();
  setStatus('View reset locally. Your real stats are untouched — reopen the popup or hit Refresh to see them again.');
}

async function handleRefresh() {
  setStatus('Refreshing...');
  await loadDashboard();
}

// ---------- Init ----------
document.addEventListener('DOMContentLoaded', () => {
  loadDashboard();
  $('loginBtn').addEventListener('click', handleLogin);
  $('passwordInput').addEventListener('keydown', (e) => e.key === 'Enter' && handleLogin());
  logoutBtn.addEventListener('click', handleLogout);
  $('resetBtn').addEventListener('click', handleReset);
  $('refreshBtn').addEventListener('click', handleRefresh);
});
