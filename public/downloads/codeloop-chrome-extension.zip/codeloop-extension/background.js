const SUPABASE_URL = 'https://khhzrsamrfkgxtbhyvda.supabase.co';
const SUPABASE_ANON_KEY =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtoaHpyc2FtcmZrZ3h0Ymh5dmRhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTAyNjQ4ODksImV4cCI6MjEwNTg0MDg4OX0.90QDd9VqEuqCFSUqFqXEtMxmiuXBbOsdclDKf2CvTww';

const LANG_MAP = {
  python: 'Python', python3: 'Python', cpp: 'C++', java: 'Java', javascript: 'JavaScript',
  typescript: 'TypeScript', golang: 'Go', c: 'C', csharp: 'C#', rust: 'Rust', kotlin: 'Kotlin',
  swift: 'Swift', ruby: 'Ruby', scala: 'Scala', php: 'PHP',
};

// ---------- session (same storage the popup writes) ----------
const getSession = () => new Promise((r) => chrome.storage.local.get(['session'], (x) => r(x.session || null)));
const setSession = (session) => new Promise((r) => chrome.storage.local.set({ session }, r));
const clearSession = () => new Promise((r) => chrome.storage.local.remove(['session'], r));

async function getValidSession() {
  const session = await getSession();
  if (!session) return null;
  if (session.expires_at && Date.now() / 1000 < session.expires_at - 30) return session;
  const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', apikey: SUPABASE_ANON_KEY },
    body: JSON.stringify({ refresh_token: session.refresh_token }),
  });
  const data = await res.json();
  if (!res.ok) { await clearSession(); return null; }
  const next = {
    access_token: data.access_token,
    refresh_token: data.refresh_token,
    expires_at: Math.floor(Date.now() / 1000) + (data.expires_in || 3600),
    user: session.user,
  };
  await setSession(next);
  return next;
}

const authHeaders = (s) => ({
  apikey: SUPABASE_ANON_KEY,
  Authorization: `Bearer ${s.access_token}`,
  'Content-Type': 'application/json',
});

// ---------- LeetCode metadata ----------
async function fetchQuestionMeta(slug) {
  const res = await fetch('https://leetcode.com/graphql', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      query: 'query q($titleSlug: String!){ question(titleSlug:$titleSlug){ title difficulty topicTags{ name } } }',
      variables: { titleSlug: slug },
    }),
  });
  const json = await res.json();
  const q = json && json.data && json.data.question;
  if (!q) throw new Error('Could not read problem details from LeetCode.');
  return { title: q.title, difficulty: q.difficulty, topic: (q.topicTags && q.topicTags[0] && q.topicTags[0].name) || 'General' };
}

// ---------- main flow ----------
const OTHER_PLATFORMS = ['GeeksforGeeks', 'Codeforces', 'HackerRank', 'CodeChef']; // must match the website's platform list

async function pushToGithub(p) {
  const { slug, lang, code, mode } = p;
  const platform = p.platform || 'LeetCode';
  if (platform !== 'LeetCode' && !OTHER_PLATFORMS.includes(platform)) throw new Error('Unsupported platform: ' + platform);
  const session = await getValidSession();
  if (!session) throw new Error('Not logged in. Click the CodeLoop extension icon and log in first.');

  // 1. Is GitHub connected? (Not required to save to CodeLoop — only to push.)
  const connRes = await fetch(`${SUPABASE_URL}/rest/v1/rpc/get_my_github_connection`, {
    method: 'POST', headers: authHeaders(session), body: '{}',
  });
  const conn = await connRes.json();
  if (!connRes.ok) throw new Error('Could not check your GitHub connection.');
  const githubConnected = Array.isArray(conn) && conn.length > 0;
  const wantsPush = mode !== 'save';

  // 2. Existing problem? Match by URL slug, or by exact title (covers problems
  //    you added by hand with a different/empty URL) so we never create duplicates.
  const isLC = platform === 'LeetCode';
  const meta = isLC
    ? await fetchQuestionMeta(slug)
    : { title: (p.title || '').trim(), difficulty: p.difficulty || 'Medium', topic: p.topic || 'General' };
  if (!meta.title) throw new Error('Missing problem title.');
  const problemUrl = isLC ? `https://leetcode.com/problems/${slug}/` : (p.url || '').split(/[?#]/)[0];

  let existing = null;
  if (isLC) {
    const byUrlRes = await fetch(
      `${SUPABASE_URL}/rest/v1/problems?user_id=eq.${session.user.id}&url=like.${encodeURIComponent('*leetcode.com/problems/' + slug + '*')}&select=id,url,github_synced`,
      { headers: authHeaders(session) }
    );
    const byUrlRows = await byUrlRes.json();
    existing = Array.isArray(byUrlRows)
      ? byUrlRows.find((r) => (/\/problems\/([^/?#]+)/.exec(r.url || '') || [])[1] === slug) || null
      : null;
  } else if (problemUrl) {
    const base = problemUrl.replace(/\/+$/, '');
    const byUrlRes = await fetch(
      `${SUPABASE_URL}/rest/v1/problems?user_id=eq.${session.user.id}&url=in.(${encodeURIComponent('"' + base + '","' + base + '/"')})&select=id,url,github_synced`,
      { headers: authHeaders(session) }
    );
    const rows = await byUrlRes.json();
    existing = Array.isArray(rows) && rows.length ? rows[0] : null;
  }
  if (!existing) {
    const esc = meta.title.replace(/[%_*]/g, '');
    const byTitleRes = await fetch(
      `${SUPABASE_URL}/rest/v1/problems?user_id=eq.${session.user.id}&platform=eq.${encodeURIComponent(platform)}&title=ilike.${encodeURIComponent(esc)}&select=id,title,url,github_synced`,
      { headers: authHeaders(session) }
    );
    const byTitleRows = await byTitleRes.json();
    if (Array.isArray(byTitleRows)) {
      existing = byTitleRows.find((r) => (r.title || '').trim().toLowerCase() === meta.title.trim().toLowerCase()) || null;
    }
  }

  if (existing && existing.github_synced) {
    return { message: wantsPush
      ? 'Already pushed to GitHub earlier — nothing new to commit.'
      : 'Already saved in CodeLoop (and pushed to GitHub earlier).' };
  }

  const language = LANG_MAP[(lang || '').toLowerCase()] || lang || 'Other';
  let problemId;

  if (existing) {
    // Update with the code you just got Accepted with
    const up = await fetch(`${SUPABASE_URL}/rest/v1/problems?id=eq.${existing.id}`, {
      method: 'PATCH', headers: { ...authHeaders(session), Prefer: 'return=minimal' },
      body: JSON.stringify({ solution: code, language }),
    });
    if (!up.ok) throw new Error('Could not update the problem in CodeLoop.');
    problemId = existing.id;
  } else {
    const ins = await fetch(`${SUPABASE_URL}/rest/v1/problems`, {
      method: 'POST', headers: { ...authHeaders(session), Prefer: 'return=representation' },
      body: JSON.stringify({
        user_id: session.user.id,
        title: meta.title,
        url: problemUrl,
        platform,
        topic: meta.topic,
        difficulty: meta.difficulty,
        language,
        solution: code,
        notes: '',
        status: 'Solved',
        next_review_at: null,
      }),
    });
    const created = await ins.json();
    if (!ins.ok) {
      const msg = (created && (created.message || created.hint)) || '';
      if (String(msg).includes('FREE_LIMIT_REACHED')) throw new Error('Free plan problem limit reached on CodeLoop.');
      throw new Error(msg || 'Could not save the problem in CodeLoop.');
    }
    problemId = Array.isArray(created) ? created[0].id : created.id;
  }

  if (!wantsPush) return { message: 'Saved to CodeLoop.' };
  if (!githubConnected) {
    return { message: 'Saved to CodeLoop. GitHub is not connected, so nothing was pushed — connect it on the CodeLoop GitHub page.' };
  }

  // 3. Commit to GitHub through the same edge function the website uses
  const syncRes = await fetch(`${SUPABASE_URL}/functions/v1/github-sync`, {
    method: 'POST', headers: authHeaders(session), body: JSON.stringify({ problem_id: problemId }),
  });
  let sync = {};
  try { sync = await syncRes.json(); } catch (_) {}
  if (!syncRes.ok || sync.error) throw new Error(sync.error || 'GitHub sync failed (saved in CodeLoop, not pushed).');
  return { message: `Pushed to ${sync.repo} (${sync.commit}).` };
}

const OTHER_SITE_PATTERNS = [
  'https://www.geeksforgeeks.org/problems/*', 'https://practice.geeksforgeeks.org/problems/*',
  'https://codeforces.com/contest/*', 'https://codeforces.com/problemset/*',
  'https://www.hackerrank.com/challenges/*', 'https://www.codechef.com/problems/*',
];

// Tabs that were already open when the extension was installed/updated/reloaded
// don't get content scripts automatically. Inject them so no manual refresh is needed.
async function injectIntoOpenTabs() {
  const lcTabs = await chrome.tabs.query({ url: 'https://leetcode.com/problems/*' }).catch(() => []);
  for (const tab of lcTabs) {
    if (!tab.id || tab.discarded) continue; // discarded tabs reload fresh (with scripts) when opened
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content/hook.js'], world: 'MAIN' });
      await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ['content/content.css'] });
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content/content.js'] });
    } catch (_) { /* restricted or closing tab — safe to skip */ }
  }
  const otherTabs = await chrome.tabs.query({ url: OTHER_SITE_PATTERNS }).catch(() => []);
  for (const tab of otherTabs) {
    if (!tab.id || tab.discarded) continue;
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content/reader.js'], world: 'MAIN' });
      await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ['content/content.css'] });
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content/other.js'] });
    } catch (_) { /* skip */ }
  }
}
chrome.runtime.onInstalled.addListener(injectIntoOpenTabs);

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.type !== 'PUSH') return;
  pushToGithub(msg.payload)
    .then((r) => sendResponse({ ok: true, message: r.message }))
    .catch((e) => sendResponse({ ok: false, error: e.message || 'Push failed.' }));
  return true; // async response
});
