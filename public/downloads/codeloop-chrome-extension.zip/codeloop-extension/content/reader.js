// Runs in the PAGE world on GeeksforGeeks / Codeforces / HackerRank / CodeChef.
// Content scripts cannot see the page's editor objects (Monaco / Ace / CodeMirror),
// so this tiny helper reads the code when the extension asks for it.
(() => {
  if (window.__codeloopReader) return;
  window.__codeloopReader = true;

  const LANG = {
    python: 'Python', python3: 'Python', c_cpp: 'C++', cpp: 'C++', 'text/x-c++src': 'C++', 'text/x-csrc': 'C',
    java: 'Java', 'text/x-java': 'Java', javascript: 'JavaScript', typescript: 'TypeScript', golang: 'Go', go: 'Go',
    csharp: 'C#', rust: 'Rust', kotlin: 'Kotlin', swift: 'Swift', ruby: 'Ruby', php: 'PHP', c: 'C', scala: 'Scala',
  };
  const norm = (id) => LANG[String(id || '').toLowerCase()] || '';

  function read() {
    // Monaco (HackerRank, CodeChef)
    try {
      const mo = window.monaco && window.monaco.editor;
      if (mo && mo.getEditors) {
        const ed = mo.getEditors().find((e) => e.getModel && e.getModel() && e.getValue().trim());
        if (ed) {
          const m = ed.getModel();
          return { code: ed.getValue(), lang: norm(m.getLanguageId ? m.getLanguageId() : '') };
        }
      }
    } catch (_) {}
    // Ace (GeeksforGeeks, Codeforces submit box, CodeChef)
    try {
      const el = document.querySelector('.ace_editor');
      const ed = el && ((el.env && el.env.editor) || (window.ace && window.ace.edit && window.ace.edit(el)));
      if (ed && ed.getValue().trim()) {
        const id = ed.session && ed.session.getMode && ed.session.getMode().$id;
        return { code: ed.getValue(), lang: norm(String(id || '').split('/').pop()) };
      }
    } catch (_) {}
    // CodeMirror 5
    try {
      const el = document.querySelector('.CodeMirror');
      const cm = el && el.CodeMirror;
      if (cm && cm.getValue().trim()) {
        const mode = cm.getOption('mode');
        return { code: cm.getValue(), lang: norm(typeof mode === 'string' ? mode : mode && mode.name) };
      }
    } catch (_) {}
    // CodeMirror 6 (renders lines as DOM text)
    try {
      const el = document.querySelector('.cm-content');
      if (el && el.innerText.trim()) return { code: el.innerText, lang: '' };
    } catch (_) {}
    // Plain textarea (largest one)
    try {
      const tas = Array.from(document.querySelectorAll('textarea')).filter((t) => (t.value || '').trim().length > 20);
      tas.sort((a, b) => b.value.length - a.value.length);
      if (tas[0]) return { code: tas[0].value, lang: '' };
    } catch (_) {}
    return { code: '', lang: '' };
  }

  window.addEventListener('message', (e) => {
    const d = e.data;
    if (e.source !== window || !d || d.source !== 'codeloop-content' || d.type !== 'READ_CODE') return;
    window.postMessage({ source: 'codeloop-reader', type: 'CODE', reqId: d.reqId, ...read() }, '*');
  });
})();
