// Runs in the PAGE world on leetcode.com/problems/*.
// Watches LeetCode's own submit + check requests so we can grab the code you
// submitted and know when the verdict is "Accepted". Nothing is sent anywhere
// from here — it only posts a message to the extension's content script.
(() => {
  if (window.__codeloopHooked) return;
  window.__codeloopHooked = true;
  const log = (...a) => { try { console.log('[CodeLoop]', ...a); } catch (_) {} };
  log('hook active on', location.pathname);
  let lastPostedAt = 0;

  const SUBMIT_RE = /\/problems\/([^/]+)\/submit\/?(\?|$)/;
  const CHECK_RE = /\/submissions\/detail\/(\d+)\/check\/?/;
  let lastSubmit = null; // { slug, lang, code, id? }
  const seen = new Set();

  function onSubmitBody(url, bodyText) {
    const m = SUBMIT_RE.exec(url);
    if (!m || !bodyText) return;
    try {
      const body = JSON.parse(bodyText);
      if (body && typeof body.typed_code === 'string') {
        lastSubmit = { slug: m[1], lang: body.lang || '', code: body.typed_code };
        log('submit captured for', m[1], '(' + (body.lang || '?') + ')');
      }
    } catch (_) { /* not JSON, ignore */ }
  }

  // The submit response tells us which submission id our captured code belongs to.
  function onSubmitResponse(url, data) {
    const m = SUBMIT_RE.exec(url);
    if (!m || !data || !lastSubmit || lastSubmit.slug !== m[1]) return;
    if (data.submission_id) lastSubmit.id = String(data.submission_id);
  }

  function onCheckResponse(url, data) {
    const m = CHECK_RE.exec(url);
    if (!m || !data || data.state !== 'SUCCESS') return; // still running
    const id = m[1];
    log('verdict for', id + ':', data.status_msg);
    if (seen.has(id)) return;
    seen.add(id);
    if (data.status_msg !== 'Accepted' || !lastSubmit) return;
    // Never attach code from a different submission to this verdict.
    if (lastSubmit.id && lastSubmit.id !== id) return;
    lastPostedAt = Date.now();
    log('Accepted — showing card');
    window.postMessage({ source: 'codeloop-hook', type: 'ACCEPTED', submissionId: id, slug: lastSubmit.slug, lang: lastSubmit.lang, code: lastSubmit.code }, '*');
  }

  // ---- Fallback: if LeetCode changed its network calls, watch the on-page
  // "Accepted" result and read the code straight from the Monaco editor. ----
  const MONACO_LANG = { python: 'python3', go: 'golang', csharp: 'csharp', cpp: 'cpp', java: 'java',
    javascript: 'javascript', typescript: 'typescript', rust: 'rust', kotlin: 'kotlin', swift: 'swift',
    ruby: 'ruby', scala: 'scala', php: 'php', c: 'c' };
  const handledEls = new WeakSet();

  function readEditor() {
    try {
      const mo = window.monaco && window.monaco.editor;
      if (!mo) return null;
      const eds = mo.getEditors ? mo.getEditors() : [];
      const ed = eds.find((e) => e.getModel && e.getModel() && e.getValue().trim()) || null;
      if (!ed) return null;
      const model = ed.getModel();
      const id = model.getLanguageId ? model.getLanguageId() : (model.getModeId && model.getModeId());
      return { code: ed.getValue(), lang: MONACO_LANG[id] || id || '' };
    } catch (_) { return null; }
  }

  function checkDom() {
    const els = document.querySelectorAll('[data-e2e-locator="submission-result"]');
    for (const el of els) {
      if (handledEls.has(el)) continue;
      if (!/^\s*Accepted\s*$/i.test(el.textContent || '')) continue;
      handledEls.add(el);
      if (Date.now() - lastPostedAt < 20000) return; // network path already handled it
      const slug = ((/\/problems\/([^/?#]+)/.exec(location.pathname) || [])[1]) || null;
      const ed = readEditor();
      if (!slug || !ed) { log('Accepted seen on page, but could not read the editor code (fallback failed)'); return; }
      lastPostedAt = Date.now();
      log('Accepted seen on page (fallback) — showing card');
      window.postMessage({ source: 'codeloop-hook', type: 'ACCEPTED', submissionId: 'dom-' + Date.now(), slug, lang: ed.lang, code: ed.code }, '*');
    }
  }
  let domTimer = null;
  const startObserver = () => {
    new MutationObserver(() => { clearTimeout(domTimer); domTimer = setTimeout(checkDom, 400); })
      .observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  };
  if (document.documentElement) startObserver();
  else document.addEventListener('DOMContentLoaded', startObserver, { once: true });

  // ---- fetch ----
  const origFetch = window.fetch;
  window.fetch = async function (input, init) {
    const url = typeof input === 'string' ? input : (input && input.url) || '';
    try {
      if (SUBMIT_RE.test(url)) {
        if (init && typeof init.body === 'string') onSubmitBody(url, init.body);
        else if (input && typeof input.clone === 'function') input.clone().text().then((t) => onSubmitBody(url, t)).catch(() => {});
      }
    } catch (_) {}
    const res = await origFetch.apply(this, arguments);
    try {
      if (SUBMIT_RE.test(url)) res.clone().json().then((d) => onSubmitResponse(url, d)).catch(() => {});
      if (CHECK_RE.test(url)) res.clone().json().then((d) => onCheckResponse(url, d)).catch(() => {});
    } catch (_) {}
    return res;
  };

  // ---- XMLHttpRequest ----
  const origOpen = XMLHttpRequest.prototype.open;
  const origSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (method, url) {
    this.__cl_url = String(url || '');
    return origOpen.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function (body) {
    const url = this.__cl_url || '';
    try {
      if (SUBMIT_RE.test(url) && typeof body === 'string') onSubmitBody(url, body);
      if (SUBMIT_RE.test(url)) {
        this.addEventListener('load', () => {
          try { onSubmitResponse(url, JSON.parse(this.responseText)); } catch (_) {}
        });
      }
      if (CHECK_RE.test(url)) {
        this.addEventListener('load', () => {
          try { onCheckResponse(url, JSON.parse(this.responseText)); } catch (_) {}
        });
      }
    } catch (_) {}
    return origSend.apply(this, arguments);
  };
})();
