// Isolated-world content script for GeeksforGeeks, Codeforces, HackerRank and CodeChef.
// Shows a "Save to CodeLoop" panel (opened automatically when a solved/Accepted
// result is detected, or manually with the floating button), prefilled with what we
// could read from the page. You can edit every field before saving.
(() => {
  if (document.documentElement.dataset.codeloopOther) return;
  document.documentElement.dataset.codeloopOther = '1';
  const log = (...a) => console.log('[CodeLoop]', ...a);

  const text = (sel, root = document) => { const e = root.querySelector(sel); return e ? e.textContent.trim() : ''; };
  const mapDiff = (s) => {
    const t = String(s || '').toLowerCase();
    if (/school|basic|easy/.test(t)) return 'Easy';
    if (/medium/.test(t)) return 'Medium';
    if (/hard/.test(t)) return 'Hard';
    return '';
  };
  const normLang = (s) => {
    const t = String(s || '');
    if (/c\+\+|cpp/i.test(t)) return 'C++';
    if (/py/i.test(t)) return 'Python';
    if (/kotlin/i.test(t)) return 'Kotlin';
    if (/javascript|node/i.test(t)) return 'JavaScript';
    if (/typescript/i.test(t)) return 'TypeScript';
    if (/java/i.test(t)) return 'Java';
    if (/c#|csharp|mono/i.test(t)) return 'C#';
    if (/rust/i.test(t)) return 'Rust';
    if (/\bgo\b|golang/i.test(t)) return 'Go';
    if (/\bc\b/i.test(t)) return 'C';
    return t.trim();
  };
  const cleanUrl = () => location.origin + location.pathname.replace(/\/+$/, '');

  // ------------------------------------------------------------------ adapters
  // test()   → is this a page we can capture from?
  // solved() → true/false when we can tell, null when we cannot (manual only)
  // read()   → { title, difficulty, language, url, code? }   (code from the page, if static)
  const ADAPTERS = [
    {
      platform: 'GeeksforGeeks',
      test: () => /(^|\.)geeksforgeeks\.org$/.test(location.hostname) && /^\/problems\//.test(location.pathname),
      solved: () => (document.body.textContent || '').includes('Problem Solved Successfully'),
      read: () => {
        const head = (document.body.innerText || '').slice(0, 4000);
        const title = text('[class*="problems_header_content__title"]') || text('h3') || text('h1')
          || document.title.split(/\s[|\-–]\s/)[0];
        const m = /Difficulty:\s*(School|Basic|Easy|Medium|Hard)/i.exec(head);
        return { title, difficulty: mapDiff(m && m[1]), language: '', url: cleanUrl() };
      },
    },
    {
      platform: 'Codeforces',
      test: () => location.hostname === 'codeforces.com' && /\/(problem\/|submission\/)/.test(location.pathname),
      solved: () => /\/submission\/\d+/.test(location.pathname) ? !!document.querySelector('.verdict-accepted') : null,
      read: () => {
        const onSubmission = /\/submission\/\d+/.test(location.pathname);
        if (onSubmission) {
          const a = document.querySelector('.datatable a[href*="/problem/"]');
          const row = document.querySelector('.datatable table tr:nth-child(2)');
          const cells = row ? row.querySelectorAll('td') : [];
          const raw = a ? a.textContent.trim() : '';
          return {
            title: raw.replace(/^[A-Z0-9]+\s*-\s*/, '') || raw,
            difficulty: '', // filled from the problem page rating below
            language: normLang(cells[3] ? cells[3].textContent : ''),
            url: a ? new URL(a.getAttribute('href'), location.origin).href.split(/[?#]/)[0] : cleanUrl(),
            code: text('#program-source-text'),
          };
        }
        const t = text('.problem-statement .title');
        return { title: t.replace(/^[A-Z0-9]+\.\s*/, '') || t, difficulty: '', language: '', url: cleanUrl() };
      },
      // Codeforces shows the rating on the problem page ("*1200"); map it to Easy/Medium/Hard.
      async enrich(info) {
        if (info.difficulty || !info.url) return info;
        try {
          const html = await (await fetch(info.url, { credentials: 'omit' })).text();
          const m = /title="Difficulty"[^>]*>\s*\*?(\d{3,4})/i.exec(html) || /\*(\d{3,4})\s*<\/span>/.exec(html);
          if (m) { const r = +m[1]; info.difficulty = r <= 1300 ? 'Easy' : r <= 1900 ? 'Medium' : 'Hard'; }
        } catch (_) { /* leave blank, user picks */ }
        return info;
      },
    },
    {
      platform: 'HackerRank',
      test: () => location.hostname === 'www.hackerrank.com' && /\/challenges\//.test(location.pathname),
      solved: () => /Congratulations/i.test(text('[class*="congrats"]')) || !!document.querySelector('[class*="congrats-wrapper"]'),
      read: () => {
        const title = text('[class*="challenge-name"]') || text('h1') || text('.hr_tour-challenge-name');
        const diff = mapDiff(text('[class*="difficulty"]'));
        const slug = (/\/challenges\/([^/]+)/.exec(location.pathname) || [])[1] || '';
        return { title, difficulty: diff, language: '', url: slug ? `https://www.hackerrank.com/challenges/${slug}/problem` : cleanUrl() };
      },
    },
    {
      platform: 'CodeChef',
      test: () => location.hostname === 'www.codechef.com' && /^\/problems\//.test(location.pathname),
      solved: () => null, // no reliable signal — use the button
      read: () => ({ title: text('h1'), difficulty: '', language: '', url: cleanUrl() }),
    },
  ];

  const current = () => ADAPTERS.find((a) => { try { return a.test(); } catch (_) { return false; } }) || null;

  // ------------------------------------------------------------------ code reader (page world)
  function readEditor() {
    return new Promise((resolve) => {
      const reqId = 'r' + Date.now() + Math.random();
      const done = (v) => { window.removeEventListener('message', onMsg); clearTimeout(t); resolve(v); };
      const onMsg = (e) => {
        const d = e.data;
        if (e.source === window && d && d.source === 'codeloop-reader' && d.reqId === reqId) done({ code: d.code || '', lang: d.lang || '' });
      };
      const t = setTimeout(() => done({ code: '', lang: '' }), 1200);
      window.addEventListener('message', onMsg);
      window.postMessage({ source: 'codeloop-content', type: 'READ_CODE', reqId }, '*');
    });
  }

  // ------------------------------------------------------------------ UI
  let panel = null;
  let fab = null;
  const el = (tag, cls, txt) => { const n = document.createElement(tag); if (cls) n.className = cls; if (txt != null) n.textContent = txt; return n; };
  const closePanel = () => { if (panel) { panel.remove(); panel = null; } if (fab) fab.style.display = ''; };

  function field(label, node) {
    const w = el('label', 'cl-field');
    w.appendChild(el('span', 'cl-label', label));
    w.appendChild(node);
    return w;
  }

  async function openPanel(adapter, auto) {
    closePanel();
    panel = el('div', 'cl-card cl-panel');

    const head = el('div', 'cl-head');
    head.appendChild(el('span', 'cl-title', '🔥 CodeLoop · ' + adapter.platform));
    const x = el('button', 'cl-close', '×');
    x.title = 'Close';
    x.addEventListener('click', closePanel);
    head.appendChild(x);

    const msg = el('div', 'cl-msg', auto ? 'Solved! Check the details, then save.' : 'Check the details, then save.');
    const title = el('input', 'cl-input');
    const diff = el('select', 'cl-input');
    ['Easy', 'Medium', 'Hard'].forEach((d) => { const o = el('option', null, d); o.value = d; diff.appendChild(o); });
    const topic = el('input', 'cl-input'); topic.value = 'General';
    const lang = el('input', 'cl-input'); lang.placeholder = 'e.g. C++';
    const code = el('textarea', 'cl-input cl-code'); code.rows = 7; code.spellcheck = false;
    code.placeholder = 'Your solution code…';

    panel.append(head, msg, field('Title', title), field('Difficulty', diff), field('Topic', topic), field('Language', lang), field('Code', code));

    const btn = el('button', 'cl-btn', 'Save + Push to GitHub');
    const saveBtn = el('button', 'cl-btn cl-btn-2', 'Save to CodeLoop only');
    panel.append(btn, saveBtn);
    document.body.appendChild(panel);
    if (fab) fab.style.display = 'none';

    // prefill (async: page DOM + editor)
    let info = { title: '', difficulty: '', language: '', url: cleanUrl() };
    try { info = Object.assign(info, adapter.read()); } catch (e) { log('read failed', e); }
    title.value = info.title || '';
    if (info.difficulty) diff.value = info.difficulty;
    lang.value = info.language || '';
    let pageCode = info.code || '';
    const ed = await readEditor();
    pageCode = pageCode || ed.code;
    if (!lang.value) lang.value = normLang(ed.lang);
    code.value = pageCode;
    if (!pageCode.trim()) {
      msg.className = 'cl-msg cl-err';
      msg.textContent = "Couldn't read your code automatically. Paste it into the Code box.";
    }
    if (adapter.enrich) { adapter.enrich(info).then((i) => { if (i.difficulty && panel) diff.value = i.difficulty; }); }

    const STALE = 'CodeLoop was updated or reloaded. Please refresh this tab once.';
    const fail = (t) => {
      msg.className = 'cl-msg cl-err'; msg.textContent = t;
      btn.disabled = false; saveBtn.disabled = false;
    };
    const run = (mode) => {
      if (!title.value.trim()) return fail('Please enter the problem title.');
      if (!lang.value.trim()) return fail('Please enter the language (e.g. C++, Python).');
      if (!code.value.trim()) return fail('Please paste your solution code.');
      btn.disabled = true; saveBtn.disabled = true;
      msg.className = 'cl-msg';
      msg.textContent = mode === 'save' ? 'Saving to CodeLoop...' : 'Saving to CodeLoop and committing to GitHub...';
      if (!chrome.runtime || !chrome.runtime.id) return fail(STALE);
      const payload = {
        platform: adapter.platform, title: title.value.trim(), url: info.url || cleanUrl(),
        difficulty: diff.value, topic: topic.value.trim() || 'General', lang: lang.value.trim(), code: code.value, mode,
      };
      try {
        chrome.runtime.sendMessage({ type: 'PUSH', payload }, (res) => {
          if (chrome.runtime.lastError) return fail('Extension error: ' + chrome.runtime.lastError.message);
          if (res && res.ok) {
            msg.className = 'cl-msg cl-ok'; msg.textContent = res.message;
            btn.remove(); saveBtn.remove();
            setTimeout(closePanel, 8000);
          } else fail((res && res.error) || 'Something went wrong.');
        });
      } catch (_) { fail(STALE); }
    };
    btn.addEventListener('click', () => run('push'));
    saveBtn.addEventListener('click', () => run('save'));
  }

  function ensureFab(adapter) {
    if (adapter && !fab) {
      fab = el('button', 'cl-fab', '🔥 Save to CodeLoop');
      fab.title = 'Save this problem and your solution to CodeLoop';
      fab.addEventListener('click', () => { const a = current(); if (a) openPanel(a, false); });
      document.body.appendChild(fab);
    } else if (!adapter && fab) {
      fab.remove(); fab = null; closePanel();
    }
  }

  // ------------------------------------------------------------------ main loop (pages are SPAs)
  let wasSolved = false;
  let lastKey = '';
  setInterval(() => {
    const a = current();
    ensureFab(a);
    if (!a) { wasSolved = false; return; }
    const key = location.pathname;
    if (key !== lastKey) { lastKey = key; wasSolved = false; }
    let s = null;
    try { s = a.solved(); } catch (_) { s = null; }
    if (s === true && !wasSolved) { wasSolved = true; log('solved detected on', a.platform); openPanel(a, true); }
    if (s === false) wasSolved = false;
  }, 1500);

  log('other-platforms script active:', (current() || {}).platform || 'not a problem page');
})();
