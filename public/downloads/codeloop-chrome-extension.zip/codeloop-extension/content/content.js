// Isolated-world content script: shows the "Push to GitHub" card after an
// Accepted submission and hands the work to the background service worker.
(() => {
  // If the extension is reloaded/updated, an older copy of this script may still be
  // alive in the tab. Only the newest copy (the one holding the token) acts.
  const token = String(Date.now()) + Math.random();
  document.documentElement.dataset.codeloopCs = token;
  const alive = () => document.documentElement.dataset.codeloopCs === token;

  console.log('[CodeLoop] content script active');
  let card = null;
  let cardSlug = null;

  const currentSlug = () => ((/\/problems\/([^/?#]+)/.exec(location.pathname) || [])[1]) || null;

  function removeCard() {
    if (card) { card.remove(); card = null; cardSlug = null; }
  }

  // LeetCode is a SPA: if you move to another problem, the old card must go.
  setInterval(() => { if (card && (!alive() || cardSlug !== currentSlug())) removeCard(); }, 1000);

  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text) n.textContent = text;
    return n;
  }

  function showCard(sub) {
    removeCard();
    cardSlug = sub.slug;
    card = el('div', 'cl-card');

    const head = el('div', 'cl-head');
    head.appendChild(el('span', 'cl-title', '🔥 CodeLoop'));
    const close = el('button', 'cl-close', '×');
    close.title = 'Dismiss';
    close.addEventListener('click', removeCard);
    head.appendChild(close);

    const msg = el('div', 'cl-msg', 'Accepted! Save this solution to CodeLoop and push it to GitHub?');
    const btn = el('button', 'cl-btn', 'Save + Push to GitHub');
    const saveBtn = el('button', 'cl-btn cl-btn-2', 'Save to CodeLoop only');

    const STALE = 'CodeLoop was updated or reloaded — please refresh this LeetCode tab once, then submit again.';

    const fail = (text) => {
      msg.className = 'cl-msg cl-err';
      msg.textContent = text;
      btn.disabled = false; saveBtn.disabled = false;
      btn.textContent = 'Retry: Save + Push to GitHub';
      saveBtn.textContent = 'Retry: Save to CodeLoop only';
    };

    const run = (mode, activeBtn) => {
      btn.disabled = true; saveBtn.disabled = true;
      activeBtn.textContent = 'Working...';
      msg.className = 'cl-msg';
      msg.textContent = mode === 'save' ? 'Saving to CodeLoop...' : 'Saving to CodeLoop and committing to GitHub...';
      if (!chrome.runtime || !chrome.runtime.id) return fail(STALE);
      try {
        chrome.runtime.sendMessage({ type: 'PUSH', payload: { ...sub, mode } }, (res) => {
          if (chrome.runtime.lastError) return fail('Extension error: ' + chrome.runtime.lastError.message);
          if (res && res.ok) {
            msg.className = 'cl-msg cl-ok';
            msg.textContent = res.message;
            btn.remove(); saveBtn.remove();
            setTimeout(removeCard, 8000);
          } else {
            fail((res && res.error) || 'Something went wrong.');
          }
        });
      } catch (_) {
        fail(STALE);
      }
    };

    btn.addEventListener('click', () => run('push', btn));
    saveBtn.addEventListener('click', () => run('save', saveBtn));

    card.append(head, msg, btn, saveBtn);
    document.body.appendChild(card);
  }

  window.addEventListener('message', (e) => {
    if (!alive()) return; // an older copy of this script — let the newest one handle it
    if (e.source !== window || !e.data || e.data.source !== 'codeloop-hook' || e.data.type !== 'ACCEPTED') return;
    if (e.data.slug !== currentSlug()) return; // result belongs to a problem we're no longer on
    console.log('[CodeLoop] showing card for', e.data.slug);
    showCard({ slug: e.data.slug, lang: e.data.lang, code: e.data.code });
  });
})();
